---
Type: 'virtual'
Oid: 949272
ObjectName: 'Holzschnitt: http://vocab.getty.edu/aat/300041405'
Inventarnummer: 'LC_HVI-19-21_23'
Title: 'Die Auferstehung (aus der Passion Christi, Folge von 14 Holzschnitten)'
Link: 'die-auferstehung-aus-der-passion-christi-folge-von-14-holzschnitten'
Zuschreibung: 'Lucas Cranach der Ältere'
Dated: 1509
DateBeginn: 1509
DateEnd: 1509
Longtext: 'The Resurrection from the "Passion Christi", a series of 14 woodcuts

Of the series only the second sheet is signed with the monogram LC, the winged serpent and dated; This image as well as The Flagellation and The Crucifixion are signed with the winged serpent insignia.

The prints were distributed both in editions of single sheets and bound in books. Numerous editions between 1509 and 1616 have been recorded.'
Classification: 'Druckgrafik'
Dimensions: 'Blockmaß: 25 x 17,2 cm (+- 5 mm)
[cda 2019]
'
BildURL: 'G_AT_A_DG1929-141'
---