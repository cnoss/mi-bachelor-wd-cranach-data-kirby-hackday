---
Type: 'virtual'
Oid: 949241
ObjectName: 'Holzschnitt: http://vocab.getty.edu/aat/300041405'
Inventarnummer: 'LC_HVI-56_79'
Title: 'Die Dornenkrönung (aus der Passion Christi, Folge von 14 Holzschnitten)'
Link: 'die-dornenkroenung'
Zuschreibung: 'Lucas Cranach der Ältere [cda 2019]'
Dated: 1506
DateBeginn: 1501
DateEnd: 1511
Longtext: Cranach depicts St Christopher here in a mountainous landscape with a broad river that creates great pictorial depth. His face clearly expresses the extreme effort required to transport the infant Christ across the river. A hermit stands with a lantern on the shore in the right background. The electoral coats of arms suspended from the boughs at the upper left suggest that the woodcut was commissioned by Friedrich III the Wise.
The block was initially dated 1506, cut in the line block, but this date was later removed, corresponding with the second state. Competition between Cranach and his contemporaries led to the development of the chiaroscuro woodcut, a tonal block, which simulated heightening by leaving parts of the paper white and it may have prompted him to deliberately antedate the first state by two years. Certain other arguments also cast doubt on the date. Cranach was not entitled to use the coat of arms with a serpent, seen on this print, until 1508 when it was granted to him by Duke Friedrich and in fact, it is not displayed on any other print before 1509. The most likely sequence of events was that Cranach learnt of the advances made in Augsburg on the invention of the tone block soon after his return from the Netherlands in 1508, and then produced his own version in the 'St Christopher' and 'Venus' woodcuts around 1509.

According to [Geisberg 1930, 594]: I. the light reflex on the knee is white; II. the light reflex on the knee has a line in the centre'
Classification: 'Druckgrafik'
Dimensions: 'Blockmaß: 28,1 x 19,7 cm (+ - 5 mm)
[cda 2019]
'
BildURL: 'G_AT_A_DG1929-104'
---
